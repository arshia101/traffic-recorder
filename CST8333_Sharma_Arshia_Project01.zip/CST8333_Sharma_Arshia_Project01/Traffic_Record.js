const axios = require("axios");
const fs = require("fs");
const csv = require("csv-parser");

class TrafficRecord {
  constructor(
    SECTIONID,
    HIGHWAY,
    SECTION,
    SECTIONLENGTH,
    SECTIONDESCRIPTION,
    date,
    DESCRIPTION,
    GROUP,
    TYPE,
    COUNTY,
    PTRUCKS,
    ADT,
    DIRECTION
  ) {
    this.SECTIONID = SECTIONID;
    this.HIGHWAY = HIGHWAY;
    this.SECTION = SECTION;
    this.SECTIONLENGTH = SECTIONLENGTH;
    this.SECTIONDESCRIPTION = SECTIONDESCRIPTION;
    this.date = date;
    this.DESCRIPTION = DESCRIPTION;
    this.GROUP = GROUP;
    this.TYPE = TYPE;
    this.COUNTY = COUNTY;
    this.PTRUCKS = PTRUCKS;
    this.ADT = ADT;
    this.DIRECTION = DIRECTION;
  }

  static createRecord(data) {
    return new TrafficRecord(
      data.SECTIONID,
      data.HIGHWAY,
      data.SECTION,
      data.SECTIONLENGTH,
      data.SECTIONDESCRIPTION,
      data.date,
      data.DESCRIPTION,
      data.GROUP,
      data.TYPE,
      data.COUNTY,
      data.PTRUCKS,
      data.ADT,
      data.DIRECTION
    );
  }

  // Read operation (get record details)
  getDetails() {
    return {
      SECTIONID: this.SECTIONID,
      HIGHWAY: this.HIGHWAY,
      SECTION: this.SECTION,
      SECTIONLENGTH: this.SECTIONLENGTH,
      SECTIONDESCRIPTION: this.SECTIONDESCRIPTION,
      date: this.date,
      description: this.DESCRIPTION,
      GROUP: this.GROUP,
      TYPE: this.TYPE,
      COUNTY: this.COUNTY,
      PTRUCKS: this.PTRUCKS,
      adt: this.ADT,
      DIRECTION: this.DIRECTION,
    };
  }

  // Update operation
  updateRecord(updatedData) {
    for (let prop in updatedData) {
      if (this.hasOwnProperty(prop)) {
        this[prop] = updatedData[prop];
      }
    }
  }

  // Delete operation
  deleteRecord() {
    // You can implement delete logic here, like marking the record as deleted in a database
    console.log("Record deleted successfully.");
  }

  // Output record data
  outputRecordData() {
    console.log("Record Data:");
    console.log("Section ID:", this.SECTIONID);
    console.log("Highway:", this.HIGHWAY);
    console.log("Section:", this.SECTION);
    console.log("Section Length:", this.SECTIONLENGTH);
    console.log("Section Description:", this.SECTIONDESCRIPTION);
    console.log("Date:", this.date);
    console.log("Description:", this.DESCRIPTION);
    console.log("Group:", this.GROUP);
    console.log("Type:", this.TYPE);
    console.log("County:", this.COUNTY);
    console.log("Percentage of Trucks:", this.PTRUCKS);
    console.log("Average Daily Traffic:", this.ADT);
    console.log("Direction:", this.DIRECTION);
    console.log("\n");
  }
}

// Function to read data from CSV file and initialize record objects
function readTrafficDataFromFile(filename, callback) {
  const records = [];
  fs.createReadStream(filename)
    .pipe(csv())
    .on("data", (row) => {
      const record = TrafficRecord.createRecord(row);
      records.push(record);
    })
    .on("end", () => {
      callback(null, records);
    })
    .on("error", (err) => {
      callback(err, null);
    });
}

// Function to fetch traffic data from an API endpoint
function fetchTrafficDataFromAPI(url, callback) {
  axios
    .get(url)
    .then((response) => {
      const data = response.data; // Assuming response.data is an array of traffic records
      const records = data.map((record) => TrafficRecord.createRecord(record));
      callback(null, records);
    })
    .catch((error) => {
      callback(error, null);
    });
}

// Display your full name
const fullName = "Arshia Sharma"; // Replace with your full name
console.log("Welcome, " + fullName + "!"); // Display full name

// Example usage:
const apiUrl = "https://api.example.com/traffic-data"; // Replace with the actual API endpoint
fetchTrafficDataFromAPI(apiUrl, (err, records) => {
  if (err) {
    console.error("Error fetching traffic data:", err);
  } else {
    console.log("Successfully fetched traffic data:");
    records.forEach((record, index) => {
      console.log(`Record ${index + 1}:`);
      record.outputRecordData();
    });
  }
});

// Example usage:

const filename = "Traffic_Volumes_-_Provincial_Highway_System.csv"; // Replace with the actual filename
readTrafficDataFromFile(filename, (err, records) => {
  if (err) {
    console.error("Error reading file:", err);
  } else {
    console.log("Successfully read records:");
    records.forEach((record, index) => {
      console.log(`Record ${index + 1}:`);
      record.outputRecordData();
    });
  }
});
